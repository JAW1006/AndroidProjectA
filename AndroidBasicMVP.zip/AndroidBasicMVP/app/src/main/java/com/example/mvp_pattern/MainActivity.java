package com.example.mvp_pattern;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.mvp_pattern.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements Presenter.View {

    private ActivityMainBinding binding;
    private Presenter.Activity presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        // Set content viewsetContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        presenter = new PresenterImpl( this);
        binding.buttonAdd.setOnClickListener(v -> presenter.onAddClicked());
        binding.buttonSubtract.setOnClickListener(v -> presenter.onSubtractClicked());
    }

    @Override
    public void showCount(int count) {
        binding.textViewCount.setText(String.valueOf(count));
    }

    @Override
    public void showTotalPrice(String totalPrice) {
        binding.textViewTotalPrice.setText(totalPrice);
    }


}