package com.example.mvp_pattern;

public interface Presenter {

    interface View {
        void showCount(int count);
        void showTotalPrice(String totalPrice);
    }

    interface Activity {
        void onAddClicked();
        void onSubtractClicked();
    }

}
