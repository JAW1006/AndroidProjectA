package com.example.mvp_pattern;

import java.text.NumberFormat;
import java.util.Locale;

public class PresenterImpl implements Presenter.Activity {

    private final Presenter.View view;
    private final Model model;

    public PresenterImpl(Presenter.View view) {
        this.view = view;
        this.model = new Model();
    }

    @Override
    public void onAddClicked() {
        model.add();
        view.showCount(model.getCount());
        //view.showTotalPrice(model.getTotalPrice());
        view.showTotalPrice(
                NumberFormat.getNumberInstance(Locale.getDefault())
                        .format(model.getTotalPrice()));
    }

    @Override
    public void onSubtractClicked() {
        model.subtract();
        view.showCount(model.getCount());
        //view.showTotalPrice(model.getTotalPrice());
        view.showTotalPrice(
                NumberFormat.getNumberInstance(Locale.getDefault())
                        .format(model.getTotalPrice()));
    }

}
